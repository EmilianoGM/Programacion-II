public enum EtipoManada
{
  Unica,
  Mixta
}
